import requests
from pymongo import MongoClient

client_mdb = MongoClient("mongodb://gc_f_user:9SjYdJbCuMm1qg5L@cluster0-shard-00-00.mhkp0.mongodb.net:27017,cluster0-shard-00-01.mhkp0.mongodb.net:27017,cluster0-shard-00-02.mhkp0.mongodb.net:27017/<dbname>?ssl=true&replicaSet=atlas-enfcuj-shard-0&authSource=admin&retryWrites=true&w=majority")
db = client_mdb.data

import boto3
from datetime import date, timedelta

s3 = boto3.client('s3', aws_access_key_id='AKIAJLRIOKZL5JRPNKHA', aws_secret_access_key='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')

yesterday = date.today() - timedelta(days=2)
yesterday = yesterday.strftime('%Y%m%d')

filename_in = 'transactions/transactions_'+yesterday+'.json'
filename_out = '/tmp/transactions.json'

s3.download_file('acb-data-122377262', filename_in, filename_out)

import json

with open(filename_out) as f:
  data = json.load(f)

intersection = [f['url'] for f in data['urls']]
intersection = [f.split('/')[-1] for f in intersection]

def run():

  urls = ['https://europe-west6-cb-src-dst.cloudfunctions.net/src_cb_fr_f0',
          'https://asia-northeast1-cb-src-dst.cloudfunctions.net/src_cb_fr_f1',
          'https://asia-northeast2-cb-src-dst.cloudfunctions.net/src_cb_fr_f2',
          'https://asia-northeast3-cb-src-dst.cloudfunctions.net/src_cb_fr_f3']
  x = 0
  retry = []
  for i,c_l in enumerate(intersection):
    params = {'message':c_l}
    r = requests.post(url = urls[x], json = params)
    if r.text == 'worked':
      print('success',c_l,i)
    else:
      print('failed url:',urls[x])
      retry.append(c_l)
    x+=1
    if x>len(urls)-1:
      x = 0

  for i,c_l in enumerate(retry):
    for url in urls:
      params = {'message':c_l}
      r = requests.post(url = url, json = params)
      if r.text == 'worked':
        print('success',c_l,i)
        break

def hello_world(request):
  run()
  return f'Hello World!'